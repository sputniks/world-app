import { Component, ViewChild, ElementRef, AfterViewInit, OnInit}  from '@angular/core';

import { jqxGridComponent } from 'jqwidgets-ng/jqxgrid'

import { HttpService } from '../http.service';

import { generatedata } from '../../../sampledata/generatedata';
@Component({
  selector: 'app-datagrid',
  templateUrl: './datagrid.component.html',
  styleUrls: ['./datagrid.component.css']
})

export class DatagridComponent {
  source: any =
  {
    localData: generatedata(200, false),
    dataType: 'array',
    datafields:
    [
      { name: 'firstname', type: 'string' },
      { name: 'lastname', type: 'string' },
      { name: 'productname', type: 'string' },
      { name: 'quantity', type: 'number' },
      { name: 'price', type: 'number' },
      { name: 'total', type: 'number' }
    ]
  };

  getWidth() : any {
    if (document.body.offsetWidth < 850) {
      return '90%';
    }
    
    return 850;
  }

  dataAdapter: any = new jqx.dataAdapter(this.source);

  columns: any[] =
  [
    { text: 'Name', dataField: 'firstname', width: 150 },
    { text: 'Last Name', dataField: 'lastname', width: 150 },
    { text: 'Product', editable: false, dataField: 'productname', width: 250 },
    { text: 'Quantity', dataField: 'quantity', width: 80, cellsalign: 'right' },
    { text: 'Unit Price', dataField: 'price', width: 80, cellsalign: 'right', cellsFormat: 'c2' },
    { text: 'Total', dataField: 'total', cellsalign: 'right', cellsFormat: 'c2' }
  ];
}



